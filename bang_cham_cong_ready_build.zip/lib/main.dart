import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(AttendanceApp());
}

class AttendanceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bảng chấm công',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.light,
      ),
      home: MonthPickerScreen(),
    );
  }
}

class MonthPickerScreen extends StatefulWidget {
  @override
  _MonthPickerScreenState createState() => _MonthPickerScreenState();
}

class _MonthPickerScreenState extends State<MonthPickerScreen> {
  DateTime selected = DateTime.now();
  late int year;
  late int month;

  @override
  void initState() {
    super.initState();
    year = selected.year;
    month = selected.month;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Bảng chấm công')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(children: [
              Expanded(
                child: DropdownButton<int>(
                  isExpanded: true,
                  value: month,
                  items: List.generate(12, (i) => i+1).map((m) => DropdownMenuItem(
                    value: m,
                    child: Text(DateFormat.MMMM('vi_VN').format(DateTime(year,m))),)).toList(),
                  onChanged: (v){ if(v!=null) setState(()=> month=v); },
                ),
              ),
              SizedBox(width: 12),
              Container(
                width: 120,
                child: TextField(
                  keyboardType: TextInputType.number,
                  controller: TextEditingController(text: year.toString()),
                  decoration: InputDecoration(labelText: 'Năm'),
                  onSubmitted: (s){ final y=int.tryParse(s); if(y!=null) setState(()=> year=y); },
                ),
              ),
              SizedBox(width: 12),
              ElevatedButton(onPressed: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AttendanceBoardScreen(year: year, month: month)));
              }, child: Text('Mở bảng'))
            ],),
            SizedBox(height:20),
            Text('Chọn tháng và năm rồi nhấn "Mở bảng" để vào giao diện chấm công.', style: TextStyle(color: Colors.grey[700])),
          ],
        ),
      ),
    );
  }
}

class AttendanceBoardScreen extends StatefulWidget {
  final int year;
  final int month;
  AttendanceBoardScreen({required this.year, required this.month});
  @override
  _AttendanceBoardScreenState createState() => _AttendanceBoardScreenState();
}

class _AttendanceBoardScreenState extends State<AttendanceBoardScreen> {
  List<String> staff = ['Ngà', 'Hà', 'Châu', 'Cường', 'Tuấn', 'Bình', 'Thi'];
  late int daysInMonth;
  Map<String, List<String>> table = {}; // name -> list of day marks: '', 'X', 'XX'
  late SharedPreferences prefs;
  String storageKey = '';

  @override
  void initState() {
    super.initState();
    daysInMonth = DateTime(widget.year, widget.month + 1, 0).day;
    storageKey = 'attendance_${widget.year}_${widget.month}';
    _load();
  }

  Future<void> _load() async {
    prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(storageKey);
    if (raw != null) {
      final Map<String, dynamic> decoded = jsonDecode(raw);
      table = decoded.map((k,v) => MapEntry(k, List<String>.from(v)));
      setState(() {});
      return;
    }
    // initialize
    for (var s in staff) {
      table[s] = List.filled(daysInMonth, '');
    }
    setState(() {});
  }

  Future<void> _save() async {
    await prefs.setString(storageKey, jsonEncode(table));
  }

  void _toggleCell(String name, int dayIndex) {
    final current = table[name]![dayIndex];
    String next;
    if (current == '') next = 'X';
    else if (current == 'X') next = 'XX';
    else next = '';
    setState(()=> table[name]![dayIndex] = next);
    _save();
  }

  void _addStaff(String name) {
    if (name.trim().isEmpty) return;
    setState((){
      staff.add(name);
      table[name] = List.filled(daysInMonth, '');
    });
    _save();
  }

  void _removeStaff(String name) {
    setState(()=> { staff.remove(name); table.remove(name); });
    _save();
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(width: 160, padding: EdgeInsets.all(8), child: Text('Tên', style: TextStyle(fontWeight: FontWeight.bold))),
        Expanded(
          child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(
            children: List.generate(daysInMonth, (i){
              final d = i+1;
              final date = DateTime(widget.year, widget.month, d);
              final wd = DateFormat.E('vi_VN').format(date);
              return Container(width: 56, padding: EdgeInsets.all(6), child: Column(children: [Text('$d', style: TextStyle(fontWeight: FontWeight.bold)), Text(wd, style: TextStyle(fontSize:12, color: Colors.grey[600]))]));
            }),
          )),
        )
      ],
    );
  }

  Widget _buildRow(String name) {
    return Row(
      children: [
        Container(width:160, padding: EdgeInsets.all(6), child: Row(children: [
          Expanded(child: Text(name)),
          IconButton(icon: Icon(Icons.edit, size:18), onPressed: () async {
            final t = await showDialog<String>(context: context, builder: (_){
              final ctrl = TextEditingController(text: name);
              return AlertDialog(title: Text('Sửa tên'), content: TextField(controller: ctrl), actions: [TextButton(onPressed: ()=> Navigator.pop(context), child: Text('Hủy')), TextButton(onPressed: ()=> Navigator.pop(context, ctrl.text), child: Text('Lưu'))]);
            });
            if (t!=null && t.trim().isNotEmpty) {
              final list = List<String>.from(table[name]!);
              table.remove(name);
              table[t] = list;
              final idx = staff.indexOf(name);
              staff[idx] = t;
              _save();
              setState((){});
            }
          }),
          IconButton(icon: Icon(Icons.delete, color: Colors.redAccent, size:18), onPressed: (){
            showDialog(context: context, builder: (_)=> AlertDialog(title: Text('Xác nhận'), content: Text('Xóa nhân viên $name?'), actions: [TextButton(onPressed: ()=> Navigator.pop(context), child: Text('Hủy')), TextButton(onPressed: (){ _removeStaff(name); Navigator.pop(context); }, child: Text('Xóa'))]));
          }),
        ])),
        Expanded(child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(
          children: List.generate(daysInMonth, (i){
            final val = table[name]![i];
            final isToday = (widget.year == DateTime.now().year && widget.month == DateTime.now().month && (i+1)==DateTime.now().day);
            Color bg;
            if (val == 'X') bg = Colors.lightGreen.shade100;
            else if (val == 'XX') bg = Colors.green.shade300;
            else bg = Colors.white;
            return GestureDetector(
              onTap: ()=> _toggleCell(name, i),
              child: Container(width:56, height:44, margin: EdgeInsets.all(4), decoration: BoxDecoration(color: bg, border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(6)),
                child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(val, style: TextStyle(fontWeight: FontWeight.bold)), if(isToday) Text('Hôm nay', style: TextStyle(fontSize:10, color: Colors.grey[700]))])),),
            );
          }),
        )))
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Bảng chấm công ${widget.month}/${widget.year}'), actions: [
        IconButton(icon: Icon(Icons.download), onPressed: () async {
          // export CSV
          final rows = <List<String>>[];
          rows.add(['Tên'] + List.generate(daysInMonth, (i)=> '${i+1}'));
          for (var name in staff) rows.add([name] + table[name]!);
          final csv = rows.map((r)=> r.map((c)=> '\"${c.replaceAll('\"','\"\"')}\"').join(',')).join('\n');
          // cannot save to file easily here; copy to clipboard not implemented
          showDialog(context: context, builder: (_)=> AlertDialog(title: Text('Xuất CSV'), content: Text('CSV đã tạo (sao chép thủ công):\\n\\n'+csv.substring(0, (csv.length>400?400:csv.length))), actions: [TextButton(onPressed: ()=> Navigator.pop(context), child: Text('Đóng'))]));
        })
      ],),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _buildHeader(),
          SizedBox(height:8),
          Expanded(child: ListView.builder(itemCount: staff.length, itemBuilder: (_,i){ final name = staff[i]; return _buildRow(name); })),
          SizedBox(height:8),
          Row(children: [
            Expanded(child: TextField(decoration: InputDecoration(hintText: 'Tên nhân viên mới', border: OutlineInputBorder()), onSubmitted: (v){ _addStaff(v); })) ,
            SizedBox(width:8),
            ElevatedButton(onPressed: (){ _save(); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Đã lưu'))); }, child: Text('Lưu'))
          ])
        ],),
      ),
    );
  }
}