
Bảng chấm công - Flutter project (ready)
========================================

Nội dung:
- pubspec.yaml
- lib/main.dart (giao diện: chọn tháng/năm -> bảng chấm công)
- assets/icon_512.png (icon tròn)
- Lưu dữ liệu offline bằng SharedPreferences

Hướng dẫn nhanh để tạo APK bằng một dịch vụ build online (ví dụ: Replit, Codemagic, Appcircle, or a Flutter build server):
1) Tải file ZIP này lên dịch vụ build hỗ trợ Flutter (hoặc git repo).
2) Chạy: flutter pub get
3) Chạy build: flutter build apk --release
4) Nếu dịch vụ yêu cầu project Android/ios, họ sẽ tự động tạo phần native khi chạy `flutter build`.
   Nếu không, bạn có thể chạy 'flutter create .' trước khi build để sinh thư mục android/ios:
     flutter create .
     flutter pub get
     flutter build apk --release

Lưu ý (với người dùng không có PC):
- Một số dịch vụ build online có nút để upload project ZIP và sẽ trả về file .apk.
- Mình khuyên dùng các dịch vụ build Flutter chuyên dụng (Codemagic, Appcircle) hoặc thuê 1 lần build từ bên thứ ba.
